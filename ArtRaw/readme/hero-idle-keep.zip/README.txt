DreamLayer sprite sheet
Action: idle
8 frames, row-major order, 512 x 512 cells, 3 columns.
Duration: 2250 ms. Sampling: cycle. A sequence is not guaranteed to loop. Shared scale; alignment: ground_anchor. Enlarged: False; enlargement adds no source detail.
Unity: slice the sheet into 512 x 512 cells.
Godot: create SpriteFrames using a 3 x 3 grid; use only the 8 atlas entries.
Phaser: load sheet.png and atlas.json with load.atlas.
