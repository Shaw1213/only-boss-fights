DreamLayer sprite sheet
Action: custom
7 frames, row-major order, 512 x 512 cells, 3 columns.
Duration: 5042 ms. Sampling: sequence. A sequence is not guaranteed to loop. Shared scale; alignment: source_canvas. Enlarged: False; enlargement adds no source detail.
Unity: slice the sheet into 512 x 512 cells.
Godot: create SpriteFrames using a 3 x 3 grid; use only the 7 atlas entries.
Phaser: load sheet.png and atlas.json with load.atlas.
